
import javax.swing.JOptionPane;

/**
 * @author Eugenio Junior
 */
public class ContaPoupanca extends Contas 
{
    private double taxa;
    
    public void setTaxa(double taxa)
    {
        this.taxa = taxa;
    }
    
    public double getTaxa()
    {
        return this.taxa;
    }
    
    public void reajustar()
    {
        double reajuste = this.getSaldo()*this.taxa;
        this.setSaldo(this.getSaldo() + reajuste);
        JOptionPane.showMessageDialog(null, "Reajuste Realizado com sucesso!");
    }
    public void reajusta ()
    {
        double reajuste = this.getSaldo()*0.1;
        this.setSaldo(this.getSaldo() + reajuste);
        JOptionPane.showMessageDialog(null, "Reajuste Realizado com a taxa padão!");
    }
    
    @Override
    public void tipoDeConta ()
    {
        JOptionPane.showMessageDialog(null, "Conta Poupança");
    }
}
